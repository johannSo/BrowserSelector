#!/bin/bash


sudo apt update && sudo apt upgrade
sudo apt autoremove
sudo apt install python3
sudo apt install pip
sudo apt install libgtk-4-dev
pip install PyGObject
sudo apt install python3-xdg
cp ../browserselector.desktop ~/.local/share/applications
